﻿using NTUCClub.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Org.BouncyCastle.Asn1.Ocsp;
using System.Threading.Channels;
using NTUCClub.Models.user;

namespace NTUCClub.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        private readonly MyDbContext _context;
        private readonly IConfiguration _configuration;
        private readonly IMapper _mapper;
        public UserController(MyDbContext context, IConfiguration configuration, IMapper mapper)
        {
            _context = context;
            _configuration = configuration;
            _mapper = mapper;
        }

        [HttpPost("register")]
        public IActionResult Register(RegisterRequest request)
        {
            // Trim string values
            request.Name = request.Name.Trim();
            request.Email = request.Email.Trim().ToLower();
            request.Password = request.Password.Trim();
            request.Phone = request.Phone.Trim();
            Console.WriteLine(request.Password);

            // Check email
            var foundUser = _context.Users.FirstOrDefault(x => x.Email == request.Email);
            if (foundUser != null)
            {
                string message = "Email already exists.";
                return BadRequest(new { message });
            }

            // Check phone
            var foundUser1 = _context.Users.FirstOrDefault(x => x.Phone == request.Phone);
            if (foundUser1 != null)
            {
                string message = "Phone already exists.";
                return BadRequest(new { message });
            }

            // Create user object
            var now = DateTime.Now;
            string passwordHash = BCrypt.Net.BCrypt.HashPassword(request.Password);
            Console.WriteLine("PWHASH", passwordHash);
            var user = new User()
            {
                Name = request.Name,
                Email = request.Email,
                Password = passwordHash,
                Phone = request.Phone,
                ProfilePicture = request.ProfilePicture,
                CreatedAt = now,
                UpdatedAt = now,
                UserType = "User"
            };
            Console.WriteLine("Password:", user.Password);


            return Ok(user);
        }
		//add user through google
		[HttpPost("register/userGoogle")]
		public IActionResult RegisterUserGoogle(GoogleRegisterRequest request)
		{
			// Trim string values
			request.name = request.name.Trim();
			request.Email = request.Email.Trim().ToLower();
			request.picture = request.picture.Trim();

			// Check email

			return Ok();

		}

		//add user
		[HttpPost("register/user")]
        public IActionResult RegisterUser(RegisterRequest request)
        {
            // Trim string values
            request.Name = request.Name.Trim();
            request.Email = request.Email.Trim().ToLower();
            request.Password = request.Password.Trim();
            request.Phone = request.Phone.Trim();
            Console.WriteLine(request.Password);

            // Check email
            var foundUser = _context.Users.FirstOrDefault(x => x.Email == request.Email);
            if (foundUser != null)
            {
                string message = "Email already exists.";
                return BadRequest(new { message });
            }

            // Check phone
            var foundUser1 = _context.Users.FirstOrDefault(x => x.Phone == request.Phone);
            if (foundUser1 != null)
            {
                string message = "Phone already exists.";
                return BadRequest(new { message });
            }

            // Create user object
            var now = DateTime.Now;
            string passwordHash = BCrypt.Net.BCrypt.HashPassword(request.Password);
            Console.WriteLine("PWHASH", passwordHash);
            var user = new User()
            {
                Name = request.Name,
                Email = request.Email,
                Password = passwordHash,
                Phone = request.Phone,
                ProfilePicture = request.ProfilePicture,
                CreatedAt = now,
                UpdatedAt = now,
                UserType = "User"
            };
            Console.WriteLine("Password:", user.Password);
            _context.Users.Add(user);
            _context.SaveChanges();
			UserDTO userDTO = _mapper.Map<UserDTO>(user);
			string accessToken = CreateToken(user);
			LoginResponse response = new()
			{
				User = userDTO,
				AccessToken = accessToken
			};
			return Ok(response);

        }
        //add admin
        [HttpPost("register/admin")]
        public IActionResult Registeradmin(RegisterRequest request)
        {
            // Trim string values
            request.Name = request.Name.Trim();
            request.Email = request.Email.Trim().ToLower();
            request.Password = request.Password.Trim();
            request.Phone = request.Phone.Trim();
            Console.WriteLine(request.Password);

            // Check email
            var foundUser = _context.Users.FirstOrDefault(x => x.Email == request.Email);
            if (foundUser != null)
            {
                string message = "Email already exists.";
                return BadRequest(new { message });
            }

            // Check phone
            var foundUser1 = _context.Users.FirstOrDefault(x => x.Phone == request.Phone);
            if (foundUser1 != null)
            {
                string message = "Phone already exists.";
                return BadRequest(new { message });
            }

            // Create user object
            var now = DateTime.Now;
            string passwordHash = BCrypt.Net.BCrypt.HashPassword(request.Password);
            Console.WriteLine("PWHASH", passwordHash);
            var user = new User()
            {
                Name = request.Name,
                Email = request.Email,
                Password = passwordHash,
                Phone = request.Phone,
                ProfilePicture = request.ProfilePicture,
                CreatedAt = now,
                UpdatedAt = now,
                UserType = "Admin"
            };
            Console.WriteLine("Password:", user.Password);
            _context.Users.Add(user);
            _context.SaveChanges();
            return Ok();

        }
        //add merchant
        [HttpPost("register/merchant")]
        public IActionResult Registermerchant(RegisterRequest request)
        {
            // Trim string values
            request.Name = request.Name.Trim();
            request.Email = request.Email.Trim().ToLower();
            request.Password = request.Password.Trim();
            request.Phone = request.Phone.Trim();
            Console.WriteLine(request.Password);

            // Check email
            var foundUser = _context.Users.FirstOrDefault(x => x.Email == request.Email);
            if (foundUser != null)
            {
                string message = "Email already exists.";
                return BadRequest(new { message });
            }

            // Check phone
            var foundUser1 = _context.Users.FirstOrDefault(x => x.Phone == request.Phone);
            if (foundUser1 != null)
            {
                string message = "Phone already exists.";
                return BadRequest(new { message });
            }

            // Create user object
            var now = DateTime.Now;
            string passwordHash = BCrypt.Net.BCrypt.HashPassword(request.Password);
            Console.WriteLine("PWHASH", passwordHash);
            var user = new User()
            {
                Name = request.Name,
                Email = request.Email,
                Password = passwordHash,
                Phone = request.Phone,
                ProfilePicture = request.ProfilePicture,
                CreatedAt = now,
                UpdatedAt = now,
                UserType = "Merchant"
            };
            Console.WriteLine("Password:", user.Password);
            _context.Users.Add(user);
            _context.SaveChanges();
            return Ok();

        }

        [HttpPost("Addadmin/{usertype}")]
        public IActionResult Addadmin(string usertype, RegisterRequest request)
        {
            if (usertype != "Admin")
            {
                return BadRequest("Only admin can perform this");
            }
            // Trim string values
            request.Name = request.Name.Trim();
            request.Email = request.Email.Trim().ToLower();
            request.Password = request.Password.Trim();
            request.Phone = request.Phone.Trim();
            Console.WriteLine(request.Password);

            // Check email
            var foundUser = _context.Users.FirstOrDefault(x => x.Email == request.Email);
            if (foundUser != null)
            {
                string message = "Email already exists.";
                return BadRequest(new { message });
            }

            // Check phone
            var foundUser1 = _context.Users.FirstOrDefault(x => x.Phone == request.Phone);
            if (foundUser1 != null)
            {
                string message = "Phone already exists.";
                return BadRequest(new { message });
            }

            // Create user object
            var now = DateTime.Now;
            string passwordHash = BCrypt.Net.BCrypt.HashPassword(request.Password);
            Console.WriteLine("PWHASH", passwordHash);
            var user = new User()
            {
                Name = request.Name,
                Email = request.Email,
                Password = passwordHash,
                Phone = request.Phone,
                ProfilePicture = request.ProfilePicture,
                CreatedAt = now,
                UpdatedAt = now,
                UserType = "Admin"
            };
            Console.WriteLine("Password:", user.Password);


            _context.Users.Add(user);
            _context.SaveChanges();
            return Ok(user);
        }
        [HttpDelete("Delete/{id}")]
        public IActionResult Delete(int id)
        {
            var foundUser = _context.Users.Where(
            x => x.Id == id).FirstOrDefault();
            string message = "Account is not found.";

            Console.WriteLine("null");
            if (foundUser == null)
            {
                return BadRequest(new { message });
            }
            _context.Users.Remove(foundUser);
            _context.SaveChanges();
            return Ok();
        }

        [HttpPost("Verification")]
        public IActionResult Verification(User data)
        {
            Console.WriteLine(data.Password.ToString());
            Console.WriteLine(data);
            _context.Users.Add(data);
            _context.SaveChanges();
            return Ok();
        }

        [HttpPost("login")]
        [ProducesResponseType(typeof(LoginResponse), StatusCodes.Status200OK)]
        public IActionResult Login(LoginRequest request)
        {
            // Trim string values
            request.Email = request.Email.Trim().ToLower();
            request.Password = request.Password.Trim();
            // Check email and password
            string message = "Email or password is not correct.";
            string messages = "no email found";

			var foundUser = _context.Users.Where(
            x => x.Email == request.Email).FirstOrDefault();
            if (foundUser == null)
            {
                return BadRequest(new { messages });
            }
            bool verified = BCrypt.Net.BCrypt.Verify(
            request.Password, foundUser.Password);


			bool check = foundUser.Password.Equals(request.Password);
			if (!verified && !check)
            {
                return BadRequest(new { message });
            }
            // Return user info
            UserDTO userDTO = _mapper.Map<UserDTO>(foundUser);
            string accessToken = CreateToken(foundUser);
            LoginResponse response = new()
            {
                User = userDTO,
                AccessToken = accessToken
            };
            return Ok(response);
        }
        [HttpGet("findemail/{email}")]
        public IActionResult FindEmail(string email)
        {
            // Trim string values
            email = email.Trim().ToLower();
            string message = "No such Email registered.";

            var foundUser = _context.Users.Where(
                x => x.Email == email).FirstOrDefault();

            if (foundUser == null)
            {
                return BadRequest(new { message });
            }
            else
            {
/*                UserDTO userDTO = _mapper.Map<UserDTO>(foundUser);
*/                return Ok(foundUser);
            }
        }
        [HttpGet("getAllUser/{usertype}")]
        public IActionResult getAllUser(string usertype)
        {
            // Trim string values
            var foundUser = _context.Users.Where(
                x => x.UserType == usertype).ToArray();
            var message = "No accounts";
            if (foundUser == null)
            {
                return Ok(new { message });
            }
            else
            {

                return Ok(foundUser);
            }
        }
        [HttpGet("userdetails/{id}")]
        public IActionResult userdetails(int id)
        {
            var foundUser = _context.Users.Where(
                x => x.Id == id).FirstOrDefault();
            if (foundUser == null)
            {
                return NotFound();
            }
            return Ok(foundUser);
        }

        [HttpPut("securitydetails/{id}")]
        public IActionResult ChangePassword(int id, UpdatePassword password)
        {

            string passwordHash = BCrypt.Net.BCrypt.HashPassword(password.Password.Trim());

            var foundUser = _context.Users.Where(
                x => x.Id == id).FirstOrDefault();
            Console.WriteLine(foundUser.Password);
            if (passwordHash != null)
            {
                foundUser.Password = passwordHash;
            }
            _context.SaveChanges();
            return Ok();

        }
        [HttpPut("updateDetails/{id}")]
        public IActionResult updateDetails(int id, User info)
        {
            Console.WriteLine(info.ProfilePicture);
            var foundUser = _context.Users.Where(
                x => x.Id == id).FirstOrDefault();
            if (foundUser == null)
            {
                return NotFound();
            }
            info.Email = info.Email.Trim();
            info.Name = info.Name.Trim();
            if (info.Email != null)
            {
                foundUser.Email = info.Email;
            }
            if (info.Name != null)
            {
                foundUser.Name = info.Name;
            }
            if (info.Phone != null)
            {
                foundUser.Phone = info.Phone;
            }
            if (info.ProfilePicture != null)
            {
                foundUser.ProfilePicture = info.ProfilePicture;
            }

            _context.SaveChanges();
            return Ok();
        }

        private string CreateToken(User user)
        {
            Console.WriteLine(user.UserType);

            string secret = _configuration.GetValue<string>(
            "Authentication:Secret");
            int tokenExpiresDays = _configuration.GetValue<int>(
            "Authentication:TokenExpiresDays");
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.Name),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Upn , user.UserType)
            }),
                Expires = DateTime.UtcNow.AddDays(tokenExpiresDays),
                SigningCredentials = new SigningCredentials(
            new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var securityToken = tokenHandler.CreateToken(tokenDescriptor);
            string token = tokenHandler.WriteToken(securityToken);
            return token;
        }

        [HttpGet("auth"), Authorize]
        [ProducesResponseType(typeof(AuthResponse), StatusCodes.Status200OK)]
        public IActionResult Auth()
        {
            var id = Convert.ToInt32(User.Claims.Where(
            c => c.Type == ClaimTypes.NameIdentifier)
            .Select(c => c.Value).SingleOrDefault());
            var name = User.Claims.Where(c => c.Type == ClaimTypes.Name)
            .Select(c => c.Value).SingleOrDefault();
            var email = User.Claims.Where(c => c.Type == ClaimTypes.Email)
            .Select(c => c.Value).SingleOrDefault();
            var usertype = User.Claims.Where(c => c.Type == ClaimTypes.Upn)
            .Select(c => c.Value).SingleOrDefault();
            if (id != 0 && name != null && email != null)
            {
                UserDTO userDTO = new() { Id = id, Name = name, Email = email, UserType = usertype };
                AuthResponse response = new() { User = userDTO };
                return Ok(response);
            }
            else
            {
                return Unauthorized();
            }
        }
        [HttpPut("claim/{id}/{VoucherId}")]
        public IActionResult Claim(int id, int VoucherId)
        {
            // Find the user with the specified ID
            var foundUser = _context.Users.FirstOrDefault(x => x.Id == id);

            // Check if the user exists
            if (foundUser == null)
            {
                return NotFound($"User with ID {id} not found");
            }

            // Find the voucher with the specified ID
            var foundVoucher = _context.Vouchers.FirstOrDefault(x => x.Id == VoucherId);

            // Check if the voucher exists
            if (foundVoucher == null)
            {
                return NotFound($"Voucher with ID {foundVoucher.Id} not found");
            }

            // Create a new list of vouchers containing only the found voucher
            foundUser.Vouchers = foundUser.Vouchers ?? new List<Voucher>();
            foundUser.Vouchers.Add(foundVoucher);

            // Save changes to the database
            _context.SaveChanges();

            return Ok("Claim operation completed successfully");
        }


    }

}
