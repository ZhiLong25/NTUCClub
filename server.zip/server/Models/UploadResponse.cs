﻿namespace NTUCClub.Models
{
    public class UploadResponse
    {
        public string Filename { get; set; } = string.Empty;
    }
}
