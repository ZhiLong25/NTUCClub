﻿namespace NTUCClub.Models
{
    public class UserBasicDTO
    {
        public string Name { get; set; } = string.Empty;
    }
}
