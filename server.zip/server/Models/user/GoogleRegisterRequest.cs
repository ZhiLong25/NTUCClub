﻿namespace NTUCClub.Models.user
{
	public class GoogleRegisterRequest
	{
		public string name{ get; set; }
		public string picture{ get; set; }
		public string Email { get; set; }
	}
}
